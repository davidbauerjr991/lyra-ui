import type { Meta, StoryObj } from "@storybook/react";
import { useState } from "react";
import { ContainerHeader } from "../container-header";
import { Button } from "../button";
import { Badge } from "../badge";
import { Settings, Maximize2, Minimize2 } from "lucide-react";
import { InfoIcon } from "../icons/info-icon";
import { Tooltip } from "../tooltip";
import { TabList, Tab } from "../tabs";

const meta: Meta<typeof ContainerHeader> = {
  title: "UI/ContainerHeader",
  component: ContainerHeader,
  tags: ["autodocs"],
  parameters: {
    layout: "padded",
    backgrounds: { default: "lyra-shell" },
  },
  argTypes: {
    title:      { control: "text" },
    bordered:   { control: "boolean" },
    background: { control: "select", options: ["none", "subtle"] },
    /* Story-only toggles below — not real `ContainerHeader` props. They let
       the Default story act as an interactive playground for the same
       patterns previously only viewable as separate fixed-render stories
       (still kept below for direct reference), plus the new "with buttons"
       pattern. Consumed and stripped out of `args` inside Default's
       `render`, below, before the rest are spread onto the real component. */
    showClose:   { control: "boolean", name: "Close button" },
    showIcon:    { control: "boolean", name: "With icon" },
    showActions: { control: "boolean", name: "With actions" },
    showBadge:   { control: "boolean", name: "With badge" },
    showSubhead: { control: "boolean", name: "With subhead" },
    showButtons: { control: "boolean", name: "With buttons" },
  } as Meta<typeof ContainerHeader>["argTypes"],
};

export default meta;
type Story = StoryObj<typeof ContainerHeader>;

export const Default: Story = {
  args: {
    title: "Container Title",
    bordered: false,
    background: "none",
    showClose: false,
    showIcon: false,
    showActions: false,
    showBadge: false,
    showSubhead: false,
    showButtons: false,
  } as Story["args"],
  render: (args: any) => {
    const { showClose, showIcon, showActions, showBadge, showSubhead, showButtons, ...rest } = args;
    return (
      <ContainerHeader
        {...rest}
        icon={showIcon ? <InfoIcon className="h-5 w-5" /> : undefined}
        onClose={showClose ? () => {} : undefined}
        titleBadge={
          showBadge ? <Badge shape="circle" count={5} variant="critical" size="sm" /> : undefined
        }
        subhead={showSubhead ? "Filter and search across all records" : undefined}
        actions={
          showActions || showButtons ? (
            <>
              {/* Left-to-right order: buttons, then actions (gear), then the
                  component's own built-in close button — actions sits
                  immediately to the left of close, buttons sits to the left
                  of actions. */}
              {showButtons && (
                <>
                  {/* No literal "secondary" button variant exists in `Button`
                      — `outline` is the design system's non-primary/bordered
                      button, i.e. the closest equivalent (see
                      Button.stories.tsx, which labels this same variant
                      "Outline" in its legend). */}
                  <Button variant="outline" size="md">Action</Button>
                  <Button variant="outline" size="md">Action</Button>
                </>
              )}
              {showActions && (
                <Button variant="ghost" size="icon" title="Settings">
                  <Settings className="h-4 w-4" strokeWidth={1.5} />
                </Button>
              )}
            </>
          ) : undefined
        }
      />
    );
  },
};

export const WithClose: Story = {
  name: "With close button",
  render: () => <ContainerHeader title="Dialog Title" bordered={false} onClose={() => {}} />,
};

export const WithIcon: Story = {
  name: "With icon",
  render: () => (
    <ContainerHeader
      title="Important notice"
      icon={<InfoIcon className="h-5 w-5" />}
      bordered={false}
      onClose={() => {}}
    />
  ),
};

export const WithActions: Story = {
  name: "With actions",
  render: () => {
    const [isFullscreen, setIsFullscreen] = useState(false);
    return (
      <ContainerHeader
        title="Query Builder"
        bordered={false}
        actions={
          <>
            <Button variant="ghost" size="icon" title="Settings">
              <Settings className="h-4 w-4" strokeWidth={1.5} />
            </Button>
            <Tooltip content={isFullscreen ? "Restore" : "Fullscreen"} placement="bottom" asLabel>
              <button
                aria-label={isFullscreen ? "Restore" : "Fullscreen"}
                onClick={() => setIsFullscreen((v) => !v)}
                className="flex h-8 w-8 items-center justify-center rounded-lyra-sm text-lyra-fg-secondary hover:bg-lyra-state-hover transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-lyra-border-focus"
              >
                {isFullscreen
                  ? <Minimize2 className="h-4 w-4" strokeWidth={1.5} />
                  : <Maximize2 className="h-4 w-4" strokeWidth={1.5} />}
              </button>
            </Tooltip>
          </>
        }
        onClose={() => {}}
      />
    );
  },
};

export const WithBadge: Story = {
  name: "With badge",
  render: () => (
    <ContainerHeader
      title="Notifications"
      titleBadge={<Badge shape="circle" count={5} variant="critical" size="sm" />}
      bordered={false}
      onClose={() => {}}
    />
  ),
};

export const WithSubhead: Story = {
  name: "With subhead",
  render: () => (
    <ContainerHeader
      title="Query Builder"
      subhead="Filter and search across all records"
      bordered={false}
      onClose={() => {}}
    />
  ),
};

export const WithButtons: Story = {
  name: "With buttons",
  render: () => (
    <ContainerHeader
      title="Query Builder"
      bordered={false}
      actions={
        <>
          <Button variant="outline" size="md">Action</Button>
          <Button variant="outline" size="md">Action</Button>
        </>
      }
      onClose={() => {}}
    />
  ),
};

export const WithTabs: Story = {
  name: "With tabs",
  render: () => {
    const [activeTab, setActiveTab] = useState(0);
    const tabs = ["Overview", "Detail", "History"];
    return (
      <ContainerHeader
        title="Customer Information"
        subhead="Noah Bennett · CST-10296"
        onClose={() => {}}
        // `tabs` renders below the title/subhead row, inside this same
        // header — see `tabs`'s own doc comment in container-header.tsx
        // for why (keeps a panel's tabs outside its scrolling body
        // entirely, rather than a `sticky` row living inside it). Bottom
        // padding and `bordered`'s border are both dropped automatically
        // whenever `tabs` is set, so the tab row sits flush with no gap
        // and no doubled-up border above its own `border-b`.
        tabs={
          <TabList className="px-4">
            {tabs.map((label, i) => (
              <Tab key={label} active={activeTab === i} onClick={() => setActiveTab(i)}>
                {label}
              </Tab>
            ))}
          </TabList>
        }
      />
    );
  },
};

export const AllVariants: Story = {
  name: "All variants",
  render: () => (
    <div className="flex flex-col divide-y divide-lyra-border-subtle border border-lyra-border-subtle rounded-lyra-lg overflow-hidden bg-lyra-bg-surface-base">
      <ContainerHeader title="Title only" bordered={false} />
      <ContainerHeader title="With close" bordered={false} onClose={() => {}} />
      <ContainerHeader title="With icon" icon={<InfoIcon className="h-5 w-5" />} bordered={false} onClose={() => {}} />
      <ContainerHeader title="With actions" bordered={false} onClose={() => {}}
        actions={<Button variant="outline" size="md">Action</Button>} />
      <ContainerHeader title="With buttons" bordered={false} onClose={() => {}}
        actions={
          <>
            <Button variant="outline" size="md">Action</Button>
            <Button variant="outline" size="md">Action</Button>
          </>
        } />
      <ContainerHeader title="With badge" bordered={false} onClose={() => {}}
        titleBadge={<Badge shape="circle" count={3} variant="default" size="sm" />} />
      <ContainerHeader title="With subhead" subhead="Secondary description text" bordered={false} onClose={() => {}} />
    </div>
  ),
};
