import type { Meta, StoryObj } from "@storybook/react";
import { useEffect, useRef, useState } from "react";
import { IdCard, Maximize2, Minimize2, PanelRightClose } from "lucide-react";
import { CustomerInformationPanel } from "../customer-information-panel";
import { PanelPinButton } from "../panel-pin-button";
import { TabList, Tab } from "../tabs";
import { Button } from "../button";
import { cn } from "../../lib/utils";

const meta: Meta<typeof CustomerInformationPanel> = {
  title: "UI/CustomerInformationPanel",
  component: CustomerInformationPanel,
  tags: ["autodocs"],
  parameters: {
    layout: "padded",
    backgrounds: { default: "lyra-shell" },
  },
};

export default meta;
type Story = StoryObj<typeof CustomerInformationPanel>;

/* ══ v2 behavior reference ══
   This story mirrors agent-next-gen-v2's CURRENT Customer Information
   panel (`CustomerInformationSidePanel`, agent-next-gen-customer-info-
   panel.tsx + the page files' own state/guards) rather than the older
   left-docked/pin-button shape this story used to show:

   — Docks on the RIGHT (`side="right"`), open + always-pinned by default.
     There is no unpin path: `onPinToggle` stays unset (so `SidePanel`'s
     built-in Pin button never renders) and the header instead carries a
     full-screen toggle + a `PanelRightClose` close button, both as
     `PanelPinButton pinned={false}` (a momentary action, not a toggle
     with a persistent highlight).
   — Header: static "Customer Information" title, subhead = the customer's
     plain name (no id — it already shows elsewhere), and the tab strip via
     `headerTabs` (`TabList overflowMenu`, `px-4`). Copilot is currently
     hidden everywhere in v2, so it's omitted from the tab list here too.
   — Sizing: starts at 340px; drag-resizable between `minWidth={325}` and
     `maxWidth = min(425, containerWidth)`; rendered width is also clamped
     to the container so it can never overhang it.
   — Narrow-container guards (all driven by the CONTAINER's own measured
     width, not the viewport — drag this story's `resize-x` edge):
       < 768px  → forced unpinned: floating overlay instead of docked, but
                  it STAYS OPEN (v2 no longer force-closes on narrow).
       ≤ 425px  → an open panel automatically goes full-screen (does NOT
                  auto-exit when widening back past 425 on its own).
       ≤ 350px  → the full-screen toggle button hides entirely; crossing
                  back ABOVE 350 exits full-screen (the one crossing that
                  does force an exit).
   — Full-screen: rendered as an unpinned overlay sized to the container's
     own full width, resize handle hidden (`resizable={false}`). Closing
     the panel also resets full-screen. */

const CUSTOMER_PANEL_TABS = [
  "Overview",
  "Interactions",
  "Detail",
  "Directory",
  "Tasks",
  "Notes",
  "Accounts",
  "Tickets",
] as const;

const PANEL_BUTTON_SELECTED_CLASS =
  "bg-lyra-bg-active-moderate text-lyra-fg-active-strong hover:bg-lyra-bg-active-moderate";

function InteractionRecordDemo({
  person,
}: {
  person: { name: string; id: string };
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [containerWidth, setContainerWidth] = useState(900);
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    setContainerWidth(el.getBoundingClientRect().width);
    const ro = new ResizeObserver(([entry]) => setContainerWidth(entry.contentRect.width));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  /* Open + pinned by default; pinned has no unpin path (v2 keeps the
     setter out entirely — only the narrow guard below ever overrides it). */
  const [open, setOpen] = useState(true);
  const pinned = true;
  const [width, setWidth] = useState(340);
  const [fullScreen, setFullScreen] = useState(false);
  const [activeTab, setActiveTab] = useState(0);

  /* Container-width pin guard — forced unpinned (floating overlay) below
     768px of the container's own width; stays OPEN. */
  const isNarrow = containerWidth < 768;
  const effectivePinned = isNarrow ? false : pinned;

  /* Auto full-screen at ≤425 (the panel's own max width) — only forces ON;
     widening back past 425 does not auto-exit. */
  const atMaxWidthBreakpoint = containerWidth <= 425;
  useEffect(() => {
    if (atMaxWidthBreakpoint && open) setFullScreen(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [atMaxWidthBreakpoint, open]);

  /* ≤350: hide the full-screen toggle; crossing back above 350 exits
     full-screen (the agent had no button to exit with while under it). */
  const atMinimalThreshold = containerWidth <= 350;
  useEffect(() => {
    if (!atMinimalThreshold) setFullScreen(false);
  }, [atMinimalThreshold]);

  /* Never render wider than the container, docked or full-screen. */
  const clampedWidth = Math.max(0, Math.min(width, containerWidth));
  const clampedMaxWidth = Math.max(0, Math.min(425, containerWidth));

  const handleClose = () => {
    setOpen(false);
    setFullScreen(false);
  };

  return (
    <div
      ref={containerRef}
      className="resize-x overflow-auto relative flex h-[560px] rounded-lyra-lg border border-lyra-border-subtle bg-lyra-bg-surface-base"
      style={{ width: 900, maxWidth: "100%" }}
    >
      {/* Stand-in for the interaction's main content column. The toggle
          button mirrors the record header's own — hidden while the panel is
          DOCKED and open (redundant next to a visibly open panel), shown
          again while closed or floating. */}
      <div className="flex flex-1 flex-col min-w-0 gap-3 p-4">
        {!(effectivePinned && open) && (
          <Button
            variant="outline"
            size="md"
            className={cn("self-start shrink-0", open && PANEL_BUTTON_SELECTED_CLASS)}
            aria-pressed={open}
            aria-label={open ? "Close Customer Information" : "Open Customer Information"}
            onClick={() => setOpen((v) => !v)}
          >
            <IdCard className="h-4 w-4 shrink-0" strokeWidth={1.5} aria-hidden="true" />
            <span>Customer Information</span>
          </Button>
        )}
        <p className="lyra-body-sm text-lyra-fg-secondary">
          Drag this card&apos;s right edge to see the v2 width guards fire:
          &lt;768px floats the panel as an overlay (still open), ≤425px
          auto-enters full screen, ≤350px hides the full-screen toggle
          (and widening back past 350 exits full screen).
        </p>
        <p className="lyra-body-sm text-lyra-fg-secondary">
          {containerWidth}px container · {effectivePinned ? "docked" : "floating overlay"}
          {fullScreen ? " · full screen" : ""}
        </p>
      </div>

      <CustomerInformationPanel
        side="right"
        open={open}
        /* Full-screen always renders unpinned — an overlay across the whole
           container, not a docked column pushing content over. */
        pinned={fullScreen ? false : effectivePinned}
        person={person}
        width={fullScreen ? containerWidth : clampedWidth}
        resizable={!fullScreen}
        minWidth={325}
        maxWidth={clampedMaxWidth}
        onWidthChange={setWidth}
        headerTabs={
          <TabList className="px-4" overflowMenu>
            {CUSTOMER_PANEL_TABS.map((label, i) => (
              <Tab key={label} active={activeTab === i} onClick={() => setActiveTab(i)}>
                {label}
              </Tab>
            ))}
          </TabList>
        }
        headerActions={
          <>
            {!atMinimalThreshold && (
              <PanelPinButton
                pinned={false}
                onToggle={() => setFullScreen((v) => !v)}
                icon={
                  fullScreen ? (
                    <Minimize2 className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
                  ) : (
                    <Maximize2 className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
                  )
                }
                pinnedLabel={fullScreen ? "Exit Full Screen" : "Full Screen"}
                unpinnedLabel={fullScreen ? "Exit Full Screen" : "Full Screen"}
              />
            )}
            <PanelPinButton
              pinned={false}
              onToggle={handleClose}
              icon={<PanelRightClose className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />}
              pinnedLabel="Close Customer Information"
              unpinnedLabel="Close Customer Information"
            />
          </>
        }
      >
        <div className="flex flex-col gap-2 px-4 py-4">
          {activeTab === 0 ? (
            <>
              {[
                ["Name", person.name],
                ["Record ID", person.id],
                ["Email", "sarah.miller@example.com"],
                ["Phone", "(555) 010-4437"],
              ].map(([label, value]) => (
                <div key={label} className="flex items-baseline justify-between gap-2">
                  <span className="lyra-body-sm text-lyra-fg-secondary">{label}</span>
                  <span className="lyra-body-sm text-lyra-fg-default truncate">{value}</span>
                </div>
              ))}
            </>
          ) : (
            <p className="lyra-body-sm text-lyra-fg-secondary">
              {CUSTOMER_PANEL_TABS[activeTab]} content goes here.
            </p>
          )}
        </div>
      </CustomerInformationPanel>
    </div>
  );
}

export const InteractionRecord: Story = {
  name: "Interaction Record (Right Docked)",
  render: () => <InteractionRecordDemo person={{ name: "Sarah Miller", id: "CST-10591" }} />,
};

/* ── Agent subject ──
   `person` isn't customer-only — an agent-to-agent consult/transfer
   interaction passes the agent's own name + id the same way. Same v2
   behavior as above, just a different subject. */
export const AgentSubject: Story = {
  name: "Agent Subject",
  render: () => <InteractionRecordDemo person={{ name: "Alex Kowalski", id: "AGT-2003" }} />,
};
