import type { Meta, StoryObj } from "@storybook/react";
import React, { useState, useEffect, useMemo, useRef } from "react";
import * as PopoverPrimitive from "@radix-ui/react-popover";
import { Draggable, type DraggableVariant, type EmbeddablePanelContent } from "../draggable";
import { AppHeader } from "../app-header";
import { AppName } from "../app-name";
import { AppMenu, type AppMenuGroup } from "../app-menu";
import { CXoneLogo } from "../cxone-logo";
import { ActionIconButton } from "../actions";
import { NotificationsBell } from "../notifications-bell";
import { useAgentNotificationsContent, type AgentNotification } from "../agent-notifications";
import { AgentChat } from "../agent-chat";
import { useAgentSearchContent } from "../agent-search";
import { useScreenPopContent } from "../screen-pop";
import { useScheduleContent } from "../schedule-panel";
import { KebabMenuButton } from "../kebab-menu-button";
import { type MenuEntry } from "../menu";
import { Badge } from "../badge";
import { Separator } from "../separator";
import { Tooltip } from "../tooltip";
import { ContainerHeader } from "../container-header";
import { AgentProfile, type AgentStatus } from "../agent-profile";
import { LeftNav, type NavItem } from "../left-nav";
import { CreateNew, useOutboundAddButton, type CreateNewOutboundContact, type CreateNewOutboundConfig } from "../create-new";
import { InteractionNavItem, type InteractionChannel, type ChannelType } from "../interaction-nav-item";
import { ChannelTab } from "../channel-row";
import { OUTBOUND_CONFIG } from "./create-new-outbound-mock";
import { ContentArea } from "../content-area";
import { Container } from "../container";
import { InteriorPanel } from "../interior-panel";
import { CustomerInformationPanel } from "../customer-information-panel";
import { PanelPinButton } from "../panel-pin-button";
import { PageHeader } from "../page-header";
import { TabList } from "../tabs";
import { Button } from "../button";
import appIcon from "../../assets/app-icon.svg";
import { Input } from "../input";
import { cn } from "../../lib/utils";
import {
  Bell,
  CalendarDays,
  GripVertical,
  Home,
  LayoutGrid,
  MessageSquare,
  MonitorUp,
  Pin,
  Search,
  Settings,
  Plus,
  User,
  UserCog,
  type LucideIcon,
} from "lucide-react";

/* ── App menu data ── */

const APP_MENU_GROUPS: AppMenuGroup[] = [
  {
    items: [
      { label: "Admin" },
      { label: "Supervisor" },
      { label: "Agent", active: true },
      { label: "Cognigy AI" },
    ],
  },
  {
    items: [
      { label: "Workforce Management" },
      { label: "Quality Management" },
      { label: "Interaction Hub" },
      { label: "My Zone" },
    ],
  },
  {
    items: [
      { label: "Dashboard" },
      { label: "Analytics" },
    ],
  },
];

/* ── Left nav data ──
   The "Create New" header uses the shared Outbound-flow config (see
   create-new-outbound-mock.tsx) rather than the old flat channel list. NAV_
   ITEMS and the header's InteractionNavItem cards mirror LeftNav.stories.tsx's
   "Agent Next Gen Left Nav" story exactly (no item marked `active` — the rail
   itself doesn't track a "current page" here, same as that story). */

const NAV_ITEMS: NavItem[] = [
  // Home + Settings only (Contacts/Directory/Schedule removed per explicit
  // request) — the rail stays minimal; everything else lives in the header
  // app-panel icons instead.
  {
    icon: <Home className="h-4 w-4" strokeWidth={1.5} />,
    label: "Home",
  },
  {
    icon: <Settings className="h-4 w-4" strokeWidth={1.5} />,
    label: "Settings",
  },
];

/** A channel open within one live interaction — tracks when it started
 *  (in ticks of the shared clock below) rather than a fixed elapsed string,
 *  so the rendered `InteractionChannel.elapsed` keeps counting up live. */
interface TrackedChannel {
  /** Unique identity for this specific channel, so two channels of the same
   *  `type` (e.g. two SMS threads on different numbers) are tracked as
   *  separate rows instead of one overwriting the other — see
   *  `InteractionChannel.id`'s own doc comment in channel-row.tsx. Built
   *  from `type` + `value` so restarting the *same* address correctly
   *  reuses/refreshes the existing row while a different address never
   *  collides with it. */
  id: string;
  type: ChannelType;
  startTick: number;
  /** Routing skill label for this channel, shown as its body copy — looked
   *  up from `OUTBOUND_CONFIG.skillOptions` at start-call time. */
  preview?: string;
  /** The phone number/email address/WhatsApp handle this channel was
   *  started on — surfaced back into CreateNew's `openChannelAddresses` so
   *  reopening the outbound picker for this contact disables only that
   *  exact address, not the whole field. See agent-next-gen-v1's own copy
   *  of this doc comment. */
  value?: string;
  /** Human-readable version of `value` for display on this channel's
   *  `ChannelTab` (e.g. "(456) 383-3329" vs. `value`'s raw "+14563833329").
   *  See agent-next-gen-v1's own copy of this field for the full rationale. */
  addressLabel?: string;
  /** Whether the customer has sent a message on this channel that the agent
   *  hasn't replied to yet — drives the row's red/critical chip+clock
   *  styling (green/success otherwise). Always omitted (falsy) at
   *  start-call/quick-dial time: an agent-initiated outbound channel has
   *  nothing pending from the customer the moment it opens, so it should
   *  never render red immediately just because its `type` isn't voice. See
   *  agent-next-gen-v1's own copy of this doc comment. */
  awaitingResponse?: boolean;
  /** Synthesized message count/conversation id shown on this channel's
   *  `ChannelTab` tooltip — see agent-next-gen-v1's own copy of these two
   *  fields for the full rationale. */
  messageCount?: number;
  interactionId?: string;
}

/** One live interaction in the left nav — an agent/customer/team/skill
 *  contact (or, for a quick-dialed number with no contact record, the
 *  number itself) plus every channel currently open with them. Keyed by
 *  contact id (or `quickdial:<number>`) so starting a second channel with
 *  the same contact adds to this interaction's `channels` instead of
 *  creating a second card — per InteractionNavItem's own design (one card
 *  per interaction, one row per channel). */
interface ActiveInteraction {
  id: string;
  customerName?: string;
  /** Customer/agent/team/skill record id shown under the name on this
   *  interaction's detail page header — the contact's real id
   *  (`CreateNewOutboundContact.subtitle`) when known, or a freshly
   *  generated case number (`generateCaseId`) for quick-dialed numbers with
   *  no matching record. See agent-next-gen-v1's own copy of this field. */
  recordId: string;
  channels: TrackedChannel[];
  /** Which open channel is "current" — shared between this interaction's
   *  InteractionNavItem card and its ChannelTab bar. See agent-next-gen-v1's
   *  own copy of this field for the full rationale. */
  currentChannelId?: string;
}

/** Fallback case id for interactions with no real record behind them
 *  (quick-dialed numbers) — see agent-next-gen-v1's own copy. */
function generateCaseId(): string {
  return `CS-${Math.floor(1000000 + Math.random() * 9000000)}`;
}

/** Synthesized per-channel conversation/session id — see agent-next-gen-v1's
 *  own copy of this helper for the full rationale. */
function generateInteractionId(): string {
  return String(Math.floor(100000000000 + Math.random() * 900000000000));
}

/** Renders a tick count (seconds since the channel/interaction started) as
 *  the "MM:SS" format InteractionNavItem's `elapsed` prop expects. */
function formatElapsedTime(totalSeconds: number): string {
  const clamped = Math.max(0, totalSeconds);
  const mm = Math.floor(clamped / 60);
  const ss = clamped % 60;
  return `${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
}

/* ── Sample notifications ── */

/** Seed data for the "Active Interaction" story below — the exact shape
 *  `handleStartCall` produces for a real outbound voice call to "Jamie
 *  Torres" (`CREATE_NEW_AGENTS[0]`, id "agent-1", `agentId` "AGT-2000") on
 *  the "General Support" skill, using the same phone/skill option values
 *  as `OUTBOUND_CONFIG` (`create-new-outbound-mock.tsx`) so this story
 *  renders identically to what starting that call by hand would produce. */
const ACTIVE_INTERACTION_DEMO: ActiveInteraction = {
  id: "agent-1",
  customerName: "Jamie Torres",
  recordId: "AGT-2000",
  channels: [
    {
      id: "voice:+14563833329",
      type: "voice",
      startTick: 0,
      preview: "General Support",
      value: "+14563833329",
      addressLabel: "(456) 383-3329",
    },
  ],
  currentChannelId: "voice:+14563833329",
};

const INITIAL_NOTIFICATIONS: AgentNotification[] = [
  { id: "1", type: "new-case",    title: "New Case",    subtitle: "Noah Patel",    timestamp: "13m ago", read: false },
  { id: "2", type: "new-chat",    title: "New Chat",    subtitle: "Sarah Miller",  timestamp: "18m ago", read: false },
  { id: "3", type: "escalation",  title: "Escalation",  subtitle: "Lauren Kim",    timestamp: "24m ago", read: false },
  { id: "4", type: "new-case",    title: "New Case",    subtitle: "Ethan Zhang",   timestamp: "37m ago", read: true  },
  { id: "5", type: "new-chat",    title: "New Chat",    subtitle: "Olivia Reed",   timestamp: "51m ago", read: true  },
  { id: "6", type: "missed-call", title: "Missed Call", subtitle: "David Brown",   timestamp: "1h ago",  read: true  },
];

/* ── Top-right app panels (ported from agent-next-gen-v2) ──
   The AppHeader's top-right area is a row of pinned app icon buttons
   (Notifications/Agent Chat/Search pinned by default) plus a trailing
   "View All Apps" kebab listing every app with a `PanelPinButton` per row.
   Every app shares ONE `Draggable`-backed panel (the template's single
   dock slot): clicking a button opens it docked showing that app; clicking
   the same button again closes it; clicking a different one swaps the
   panel's content in place — the container itself (variant/width/position)
   never changes, only its header/body content does. This replaced the two
   separate AI + Notifications panels (and the standalone Ask AI header
   button) this template used to carry — v2's Desk header has no AI button,
   and with a single shared panel there's no cross-panel single-dock rule
   left to enforce. For an isolated Storybook sandbox of the underlying
   multi-panel Draggable mechanics, see Draggable.stories.tsx's
   `MultiplePanelsSingleDock` story.

   Deliberate simplifications vs. agent-next-gen-v2 (story scope):
   - No drag-to-reorder of the header icons / menu rows (v2's
     `useColumnReorder` wiring).
   - No responsive hide/reveal of pinned icons (v2's measured 16px/84px
     hysteresis against `AppName`).
   - No <768px combined-panel two-tab mode; the template keeps its existing
     "close + undock when the viewport narrows" behavior instead.
   - No per-app fullscreen (v2's Maximize2 header action + overlay). */

type PanelKey = "search" | "wem" | "screenpop" | "conversations" | "schedule" | "notif";

/** Per-key label/icon for the header icon buttons AND the "View All Apps"
 *  menu rows — centralized so the two can't drift apart. "notif" uses
 *  `Bell` for its menu row only; the header itself renders the specialized
 *  `NotificationsBell` (badge count) for that key instead. "conversations"
 *  is v2's internal key for the renamed "Agent Chat" panel — kept so the
 *  two implementations stay greppable against each other. */
const PANEL_KEY_METADATA: Record<PanelKey, { label: string; icon: LucideIcon }> = {
  search: { label: "Search", icon: Search },
  // WEM = Workforce Engagement Management
  wem: { label: "WEM", icon: UserCog },
  screenpop: { label: "Screen Pop", icon: MonitorUp },
  conversations: { label: "Agent Chat", icon: MessageSquare },
  schedule: { label: "Schedule", icon: CalendarDays },
  notif: { label: "Notifications", icon: Bell },
};

/** Fixed order for the header icon row and the "View All Apps" menu — v2's
 *  `PANEL_KEY_INITIAL_ORDER` filtered to the keys this template carries
 *  (user-reorderable there; static here, see the simplifications note). */
const PANEL_KEY_ORDER: PanelKey[] = ["search", "wem", "screenpop", "conversations", "schedule", "notif"];

/** Default pinned set — header shows (left to right) Search, Agent Chat,
 *  Notifications; the rest start unpinned but stay reachable from "View
 *  All Apps". Matches v2's own defaults. */
const DEFAULT_PINNED_KEYS: Record<PanelKey, boolean> = {
  search: true,
  wem: false,
  screenpop: false,
  conversations: true,
  schedule: false,
  notif: true,
};

/** "Selected" treatment for whichever AppHeader icon button currently owns
 *  the shared panel — the same `bg-lyra-bg-active-moderate`/`text-lyra-fg-
 *  active-strong` "active" idiom `PanelPinButton`/`LeftNav`/`Tabs` already
 *  use (and lyra-ui's own "Multiple Containers" Draggable.stories.tsx
 *  demos), not a plain hover tint. */
const PANEL_BUTTON_SELECTED_CLASS = "bg-lyra-bg-active-moderate text-lyra-fg-active-strong hover:bg-lyra-bg-active-moderate";

const APP_PANEL_DEFAULT_WIDTH = 360;

/* ── Shared-panel min/max width behavior — ported from v2's
   `AgentNextGenPage.tsx` so this template's docked panel and main content
   column size identically to v2's (previously this template used a
   never-validated `minWidth={280}` and `Draggable`'s built-in generic
   responsive max, which made the containers render slightly different
   widths than v2). See v2's own doc comments on these constants for the
   full reasoning; summarized here. ── */

/* The true VISUAL minimum content width the main content column
   (`containerRef`) and the docked shared panel should both deliver at
   their floors — the same on-screen size at minimum, not just the same
   raw CSS number. The docked panel's outer box has no padding of its own,
   so it uses this value directly as `Draggable`'s `minWidth`; the main
   content column pays a `pr-3` padding tax on top (see
   `INTERACTION_MAIN_CONTENT_MIN_WIDTH`). */
const SHARED_CONTENT_MIN_VISUAL_WIDTH = 362;

/* `containerRef`'s own border-box floor: `SHARED_CONTENT_MIN_VISUAL_WIDTH`
   + 12 (its `pr-3`), so the CONTENT area — not the padded border-box —
   never drops below the shared visual minimum. The literal `min-w-[374px]`
   class on `containerRef`'s div must be kept in sync with this by hand
   (Tailwind arbitrary-value classes need a literal string at build time). */
const INTERACTION_MAIN_CONTENT_MIN_WIDTH = SHARED_CONTENT_MIN_VISUAL_WIDTH + 12;

/* Absolute ceiling for the shared panel in any variant (docked also gets
   the floor-aware `maxDockedWidthForMainFloor` cap, computed in-component). */
const SHARED_PANEL_MAX_WIDTH = 1024;

function AgentNextGenTemplate({
  showPageHeader = false,
  showPanelToggle = false,
  showInteriorPanel = true,
  initialInteraction,
  sidePanelToggleLabel,
}: {
  showPageHeader?: boolean;
  showPanelToggle?: boolean;
  showInteriorPanel?: boolean;
  /**
   * Seeds `interactions`/`activeInteractionId` with an already-active call,
   * for stories that need to render the interaction detail view directly
   * (e.g. "Active Interaction") instead of requiring a manual New Outbound
   * click first. Shaped exactly like what `handleStartCall` itself would
   * produce, so it's indistinguishable from a real session once rendered.
   */
  initialInteraction?: ActiveInteraction;
  /**
   * Overrides the record-header `PanelPinButton`'s tooltip — both the
   * pinned and unpinned label, since a story-specific override like
   * "Toggle Overview" describes the action generically rather than the
   * pin/unpin state pair "Unpin/Pin Designer panel" defaults to. Leave
   * unset to keep those defaults.
   */
  sidePanelToggleLabel?: string;
}) {
  const [navOpen, setNavOpen] = useState(!!initialInteraction);
  // No interactions exist until the agent launches one from the CreateNew
  // menu (Start Interaction / quick dial) — see handleStartCall/handleQuick
  // Dial below. Click any resulting InteractionNavItem card to make it the
  // active one, same interactive pattern as LeftNav.stories.tsx's "Agent
  // Next Gen Left Nav" story. `initialInteraction` (see above) seeds this
  // instead, for stories that want to start already mid-call.
  const [interactions, setInteractions] = useState<ActiveInteraction[]>(
    () => (initialInteraction ? [initialInteraction] : [])
  );
  const [activeInteractionId, setActiveInteractionId] = useState<string | null>(
    () => initialInteraction?.id ?? null
  );
  // Drives the main content area — see agent-next-gen-v1's own copy of this
  // derived value and the PageHeader switch below.
  const activeInteraction = interactions.find((i) => i.id === activeInteractionId) ?? null;
  // Shared clock powering every open channel's live "MM:SS since it
  // started" elapsed display — independent of `elapsedSeconds` below, which
  // is the agent's own status timer and resets on status change.
  const [clockTick, setClockTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setClockTick((t) => t + 1), 1000);
    return () => clearInterval(id);
  }, []);
  const [windowWidth, setWindowWidth] = useState(() => window.innerWidth);
  const [notifications, setNotifications] = useState(INITIAL_NOTIFICATIONS);
  // Search app panel's query — lifted here per the controlled-components
  // convention (the panel's SearchInput reports into template state).
  const [globalSearchQuery, setGlobalSearchQuery] = useState("");
  // Screen Pop app panel's selected external app. Defaults to "salesforce"
  // (matching the reference) so the panel opens straight into the mocked
  // Salesforce login instead of an empty picker.
  const [screenPopApp, setScreenPopApp] = useState("salesforce");
  const [agentStatus, setAgentStatus] = useState<AgentStatus>("available");
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [appMenuOpen, setAppMenuOpen] = useState(false);

  /* Panel animation state machine
   * "closed"  → visibility:hidden + data-state="closed" (preserves Draggable offset, no display:none flash)
   * "open"    → visibility:visible + data-state="open"  (enter animation plays)
   * "closing" → visibility:visible + data-state="closed" (exit animation plays)
   *
   * Using visibility:hidden instead of display:none avoids a GPU compositor race where
   * one frame of the enter animation's fill-mode (opacity:0) can appear before display:none
   * propagates to the compositor — the root cause of the close flicker.
   */
  type PanelState = "closed" | "open" | "closing";

  /* Shared app panel state — ONE Draggable-backed panel every top-right app
     button (Search/WEM/Screen Pop/Agent Chat/Schedule/Notifications) shares;
     `activePanelKey` picks whose content it currently shows. See the
     "Top-right app panels" comment above the component. */
  const [activePanelKey,  setActivePanelKey]  = useState<PanelKey | null>(null);
  const [panelOpen,       setPanelOpen]       = useState(false);
  const [panelMounted,    setPanelMounted]    = useState(false); // true after first open, never resets
  const [panelState,      setPanelState]      = useState<PanelState>("closed");
  const [panelVariant,    setPanelVariant]    = useState<DraggableVariant>("docked");
  const [panelWidth,      setPanelWidth]      = useState(APP_PANEL_DEFAULT_WIDTH);
  const [panelHeight,     setPanelHeight]     = useState(860);
  const [panelIsResizing, setPanelIsResizing] = useState(false);
  /* Which apps show a persistent header icon — toggled per row from the
     "View All Apps" menu's `PanelPinButton`s. An unpinned app just loses
     its header icon; it stays reachable from that menu. */
  const [pinnedKeys, setPinnedKeys] = useState<Record<PanelKey, boolean>>(DEFAULT_PINNED_KEYS);
  /* Tracked only so the "View All Apps" Tooltip can be disabled while the
     menu is open — trigger and tooltip share the same DOM node, see
     `KebabMenuButton.onOpenChange`'s own doc comment. */
  const [appsMenuOpen, setAppsMenuOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  // Body row (LeftNav + content + docked panel) width — feeds
  // `maxDockedWidthForMainFloor` below, same measurement v2's
  // `bodyContainerRef` takes. Distinct from `containerWidth` (the content
  // area only), which shrinks as the docked panel grows and so can't anchor
  // the panel's own ceiling without feedback.
  const bodyContainerRef = useRef<HTMLDivElement>(null);
  const [bodyContainerWidth, setBodyContainerWidth] = useState(9999);
  useEffect(() => {
    const el = bodyContainerRef.current;
    if (!el) return;
    setBodyContainerWidth(el.getBoundingClientRect().width);
    const ro = new ResizeObserver(([entry]) => setBodyContainerWidth(entry.contentRect.width));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const panelFloatLeft = useRef<number | null>(null);
  const panelFloatTop  = useRef<number | null>(null);
  // Ref on the Draggable root — getBoundingClientRect() here includes the CSS
  // transform drag offset, so we capture the actual visual position before docking.
  const panelRef  = useRef<HTMLDivElement>(null);
  const panelAnimTimer = useRef<ReturnType<typeof setTimeout>>();

  /* Interior panel (right) */
  const [interiorPanelOpen, setInteriorPanelOpen] = useState(false);

  /* Side panel */
  const [sidePanelOpen,      setSidePanelOpen]      = useState(false);
  const [sidePanelPinned,    setSidePanelPinned]    = useState(false);
  const [sidePanelResizing,  setSidePanelResizing]  = useState(false);
  const [sidePanelWidth,     setSidePanelWidth]     = useState(256);
  const [containerWidth,     setContainerWidth]     = useState(9999);
  const sidePanelTimer = useRef<ReturnType<typeof setTimeout>>();

  // Track container width to force unpinned below 1024px — matches
  // `AdminShell`'s own "container-width pin guard" (admin-shell.tsx)
  // exactly. Previously 768px here vs. 1024px there — two different
  // thresholds for what's meant to be the same responsiveness behavior
  // (same pin-guard pattern, just different content/icons), per "the side
  // panel components for admin and agent should functionally be the same
  // ... from a responsiveness perspective they should not be different."
  // Unified on 1024px.
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    setContainerWidth(el.getBoundingClientRect().width);
    const ro = new ResizeObserver(([entry]) => setContainerWidth(entry.contentRect.width));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const isNarrowContainer = containerWidth < 1024;
  // When narrow: force overlay mode and hide pin button
  const effectivePinned = isNarrowContainer ? false : sidePanelPinned;

  // Close the Designer panel the moment the container drops below 1024px,
  // so an open-and-pinned panel doesn't instantly become an open-and-
  // FLOATING overlay the moment `effectivePinned` above flips to `false`.
  // Deliberately does NOT reset `sidePanelPinned` itself — only `sidePanelOpen`
  // — so widening back out past 1024px naturally restores open-and-pinned
  // from the untouched `sidePanelPinned`, rather than requiring the user to
  // manually re-pin every time. Matches `admin-shell.tsx`'s own "Container-
  // width pin guard" exactly (see its comment for the full rationale,
  // including why a prior pass here that also reset `sidePanelPinned` was
  // reversed) — see agent-next-gen-v1's copy of this effect too.
  const skipFirstSidePanelNarrowRun = useRef(true);
  useEffect(() => {
    if (skipFirstSidePanelNarrowRun.current) { skipFirstSidePanelNarrowRun.current = false; return; }
    if (isNarrowContainer) {
      setSidePanelOpen(false);
    } else {
      setSidePanelOpen(sidePanelPinned);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isNarrowContainer]);

  // The Designer panel belongs to the interaction it was opened from — its
  // only trigger is the record icon on the interaction `PageHeader`, which
  // doesn't exist outside an interaction. See agent-next-gen-v1's copy of
  // this effect for the full rationale.
  useEffect(() => {
    if (!activeInteractionId) {
      setSidePanelOpen(false);
      setSidePanelPinned(false);
    }
  }, [activeInteractionId]);

  // Track window width for nav overlay breakpoint
  useEffect(() => {
    const onResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  const isNavNarrow = windowWidth < 1280;
  const isCompactHeader = windowWidth < 760;

  // Auto-collapse the expanded nav when viewport drops below 1280px
  useEffect(() => {
    if (isNavNarrow && navOpen) setNavOpen(false);
  }, [isNavNarrow]); // eslint-disable-line react-hooks/exhaustive-deps

  // Close and undock a docked app panel when viewport drops below 1280px —
  // the template's pre-existing behavior, kept in place of v2's <768px
  // combined-panel two-tab mode (out of scope here, see the simplifications
  // note above the component).
  useEffect(() => {
    if (isNavNarrow && panelVariant === "docked") {
      setPanelVariant("float");
      setPanelOpen(false);
    }
  }, [isNavNarrow]); // eslint-disable-line react-hooks/exhaustive-deps

  // Both guarded on `sidePanelPinned` — matches `admin-shell.tsx`'s
  // `handleLeftHoverStart`/`handleLeftHoverEnd` (the canonical `SidePanel`
  // reference): hover previews the panel while *unpinned* only. Once
  // pinned, hover does nothing at all in either direction — open/closed is
  // controlled exclusively by the click toggle (`handleSidePanelIconToggle`)
  // while pinned, same as every other `SidePanel` consumer in this system.
  // `onSidePanelHoverStart` used to have no pinned guard at all, so hovering
  // the icon could silently reopen a pinned-but-closed panel — inconsistent
  // with the click-only contract above. (Still no `sidePanelHoverEnabled`
  // flag or other hidden gating beyond this one plain check — that flag was
  // removed earlier this session for leaving a stricter one-off "click to
  // reopen" state stuck after an icon-click unpin; this fix is orthogonal to
  // that and doesn't reintroduce it.)
  const onSidePanelHoverStart = () => {
    if (sidePanelPinned) return;
    clearTimeout(sidePanelTimer.current);
    setSidePanelOpen(true);
  };
  const onSidePanelHoverEnd = () => {
    if (sidePanelPinned) return;
    sidePanelTimer.current = setTimeout(() => setSidePanelOpen(false), 300);
  };
  const handleSidePanelPinToggle = () => {
    setSidePanelPinned((v) => !v);
    setSidePanelOpen(true); // keep open when toggling pin state
  };
  /* Click on the interaction record icon — toggles open/closed only, and
     only while already pinned (matching `admin-shell.tsx`'s
     `handleLeftToggle`/`handleRightToggle`: a no-op while unpinned, since
     that state is hover-driven instead). Deliberately does NOT touch
     `sidePanelPinned` — pinning/unpinning is `handleSidePanelPinToggle`'s
     job alone (the panel's own internal pin button). This used to also
     flip `sidePanelPinned` to match, which meant "closing" a pinned panel
     via this icon silently unpinned it too — so reopening it later (e.g. by
     hovering) came back unpinned instead of staying pinned like Panel.
     stories.tsx's "Side Panel" reference behavior requires. See
     agent-next-gen-v1's copy of this handler for the full rationale. */
  const handleSidePanelIconToggle = () => {
    if (effectivePinned) setSidePanelOpen((v) => !v);
  };

  const MAX_PANEL_HEIGHT = 860;
  const BOTTOM_PADDING   = 8;

  const computePanelHeight = () => {
    if (!containerRef.current) return MAX_PANEL_HEIGHT;
    const top = containerRef.current.getBoundingClientRect().top;
    return Math.min(window.innerHeight - top - BOTTOM_PADDING, MAX_PANEL_HEIGHT);
  };

  /* Timer */
  useEffect(() => {
    const id = setInterval(() => setElapsedSeconds((s) => s + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const h = Math.floor(elapsedSeconds / 3600);
  const m = Math.floor((elapsedSeconds % 3600) / 60);
  const s = elapsedSeconds % 60;
  const formattedTimer = `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;

  const handleStatusChange = (status: AgentStatus) => {
    setAgentStatus(status);
    setElapsedSeconds(0);
  };

  /* ── Launching interactions from CreateNew ──
     Overrides OUTBOUND_CONFIG's default onStartCall/onQuickDial (which just
     console.log) so this template actually surfaces what gets launched as
     InteractionNavItem cards in the left nav, instead of always showing the
     same 3 fixed demo cards regardless of what the agent does. Each handler
     below also expands the nav (`setNavOpen(true)`) — a collapsed rail would
     otherwise hide the card it just launched/updated from view entirely, so
     starting a call always surfaces it regardless of whether the nav
     happened to be collapsed at the time. */
  const handleStartCall = (selection: {
    contact: CreateNewOutboundContact;
    channel: ChannelType;
    phone: string;
    skillId: string;
  }) => {
    const skillLabel = OUTBOUND_CONFIG.skillOptions.find((o) => o.value === selection.skillId)?.label;
    // `phoneOptions` only has a value→label mapping for phone numbers (raw
    // digits → formatted display string) — email/WhatsApp addresses are
    // already human-readable as-is (see `create-new.tsx`'s
    // `defaultDetailValueFor`, where their `value` and `label` are the same
    // string), so falling back to `selection.phone` itself is correct there,
    // not a placeholder.
    const addressLabel = OUTBOUND_CONFIG.phoneOptions.find((o) => o.value === selection.phone)?.label ?? selection.phone;
    // A freshly started outbound conversation hasn't exchanged any messages
    // yet — `0` (not omitted) so the tooltip actually reads "0 Messages"
    // instead of showing nothing. Voice has no message concept at all, so
    // it's left `undefined` there — see agent-next-gen-v1's own copy of
    // this logic for the full rationale.
    const newChannel: TrackedChannel = {
      id: `${selection.channel}:${selection.phone}`,
      type: selection.channel,
      startTick: clockTick,
      preview: skillLabel,
      value: selection.phone,
      addressLabel,
      messageCount: selection.channel === "voice" ? undefined : 0,
      interactionId: generateInteractionId(),
    };

    setInteractions((prev) => {
      const idx = prev.findIndex((i) => i.id === selection.contact.id);
      // No existing interaction with this contact — start a new card.
      if (idx === -1) {
        return [...prev, {
          id: selection.contact.id,
          customerName: selection.contact.name,
          recordId: selection.contact.subtitle ?? generateCaseId(),
          channels: [newChannel],
          currentChannelId: newChannel.id,
        }];
      }
      // Same contact already has an interaction open — restart the matching
      // channel's timer if this is the *same* type+address (e.g. redialing
      // the same SMS number), or add a new row alongside the existing ones
      // if it's a different address on the same type (e.g. a second SMS
      // thread on a different number) — those are genuinely separate
      // conversations, not a duplicate of the first, so they shouldn't
      // overwrite it.
      return prev.map((interaction, i) => {
        if (i !== idx) return interaction;
        const chIdx = interaction.channels.findIndex((c) => c.id === newChannel.id);
        const channels = chIdx === -1
          ? [...interaction.channels, newChannel]
          : interaction.channels.map((c, j) => (j === chIdx ? newChannel : c));
        return { ...interaction, channels, currentChannelId: newChannel.id };
      });
    });
    setActiveInteractionId(selection.contact.id);
    setNavOpen(true);
  };

  const handleQuickDial = (phoneNumber: string) => {
    // No contact record for a quick-dialed number — key the card off the
    // number itself so redialing the same number restarts its card rather
    // than stacking up duplicates.
    const id = `quickdial:${phoneNumber}`;
    // Voice has no message concept at all, so `messageCount` is left
    // undefined here (not `0`) — see the `handleStartCall` comment above.
    const newChannel: TrackedChannel = {
      id: "voice",
      type: "voice",
      startTick: clockTick,
      value: phoneNumber,
      addressLabel: phoneNumber,
      interactionId: generateInteractionId(),
    };
    setInteractions((prev) => {
      const idx = prev.findIndex((i) => i.id === id);
      if (idx === -1) return [...prev, { id, recordId: generateCaseId(), channels: [newChannel], currentChannelId: newChannel.id }];
      return prev.map((interaction, i) => (i === idx ? { ...interaction, channels: [newChannel], currentChannelId: newChannel.id } : interaction));
    });
    setActiveInteractionId(id);
    setNavOpen(true);
  };

  /* "Unassign & Dismiss" — `InteractionNavItem` itself decides which of
     these two applies (based on how many channels the card has open when
     it's clicked): `onDismiss` (whole card, only called when just one
     channel was open) removes the interaction entirely, clearing
     `activeInteractionId` too if it was the active one; `onDismissChannel`
     (only called when more than one channel was open) drops just that one
     channel, leaving the rest of the card open. */
  const handleDismissInteraction = (id: string) => {
    setInteractions((prev) => prev.filter((interaction) => interaction.id !== id));
    setActiveInteractionId((current) => (current === id ? null : current));
  };

  const handleDismissChannel = (id: string, channel: Pick<InteractionChannel, "id" | "type">) => {
    // Match on `id` (falling back to `type`, same as InteractionNavItem's
    // own `channelKey` convention) rather than `type` alone — two open
    // channels can share a `type` (e.g. two SMS threads on different
    // numbers), and filtering by `type` would drop *both* instead of just
    // the one the agent actually dismissed.
    const dismissedKey = channel.id ?? channel.type;
    setInteractions((prev) =>
      prev.map((interaction) => {
        if (interaction.id !== id) return interaction;
        const channels = interaction.channels.filter((c) => (c.id ?? c.type) !== dismissedKey);
        const currentChannelId = interaction.currentChannelId === dismissedKey
          ? channels[channels.length - 1]?.id
          : interaction.currentChannelId;
        return { ...interaction, channels, currentChannelId };
      })
    );
  };

  /** Fired by a card row's `onCurrentChannelChange` or a `ChannelTab`'s
   *  `onClick` — see `ActiveInteraction.currentChannelId`'s own doc comment. */
  const handleChannelSelect = (interactionId: string, channelKey: string) => {
    setInteractions((prev) =>
      prev.map((interaction) =>
        interaction.id === interactionId ? { ...interaction, currentChannelId: channelKey } : interaction
      )
    );
  };

  /* ── Preventing duplicate channels from the CreateNew picker ──
     A contact already reachable via a currently-open channel still shows
     that channel in "Select Channel" and every address in the detail
     screen's second field ("Select Phone"/"Select Email Address"/"Select
     WhatsApp Handle") — except whichever exact address(es) are already in
     use, which are disabled so starting another interaction on one of them
     wouldn't just duplicate the one already running (a different, still-
     unused outbound line for the same channel stays selectable).
     `CreateNewOutboundContact.openChannelAddresses` is exactly the
     mechanism `CreateNew` exposes for this (see its own doc comment), so
     rather than adding new disabling logic to that shared component, this
     derives a per-render copy of OUTBOUND_CONFIG that tags each contact
     with every address in use for whichever channels they already have
     open in `interactions` (read off each `TrackedChannel.value` — a
     contact can have more than one channel of the same type open at once,
     e.g. two SMS threads on different numbers, so this is a list per
     channel type, not a single address), across every group. Recomputed
     whenever `interactions` changes so an address re-enables the moment its
     interaction is dismissed. See agent-next-gen-v1's AgentNextGenPage.tsx
     for the mirrored consumer app implementation. */
  const outboundConfig = useMemo<CreateNewOutboundConfig>(() => {
    const openAddressesByContactId = new Map<string, Partial<Record<ChannelType, string[]>>>(
      interactions.map((interaction) => {
        const byType: Partial<Record<ChannelType, string[]>> = {};
        for (const c of interaction.channels) {
          if (!c.value) continue;
          (byType[c.type] ??= []).push(c.value);
        }
        return [interaction.id, byType];
      })
    );
    return {
      ...OUTBOUND_CONFIG,
      groups: OUTBOUND_CONFIG.groups.map((group) => {
        if (!group.contacts) return group;
        return {
          ...group,
          contacts: group.contacts.map((contact) => {
            const openChannelAddresses = openAddressesByContactId.get(contact.id);
            if (!openChannelAddresses || Object.keys(openChannelAddresses).length === 0) return contact;
            return { ...contact, openChannelAddresses };
          }),
        };
      }),
    };
  }, [interactions]);

  // Every "Agent Next Gen" consumer (this story, agent-next-gen-v1's
  // AgentNextGenPage.tsx, LeftNav.stories.tsx's "Agent Next Gen Left Nav"
  // story, InteractionNavItem.stories.tsx) wants the exact same "+" behavior
  // on each InteractionNavItem card — look up that interaction's underlying
  // outbound contact and scope the flyout to whatever channels it actually
  // supports. That's `useOutboundAddButton` (create-new.tsx) — a single
  // shared implementation instead of hand-copied ones that could (and did)
  // quietly drift out of sync. `OutboundAddButton` is fully self-contained
  // now (no more `launchRequest`/`onLaunchRequestHandled` — see its own doc
  // comment in create-new.tsx), so there's nothing to wire into this story's
  // own `CreateNew` instance anymore.
  // `onStartCall: handleStartCall` override is required — `outboundConfig`
  // itself still carries whatever placeholder `onStartCall` it was built
  // with (see its own `useMemo` above), not this story's real
  // `handleStartCall`, so the bare `outboundConfig` here would silently
  // no-op "Start Interaction" instead of opening a card (same bug fixed in
  // agent-next-gen-v1/AgentNextGenPage.tsx and LeftNav.stories.tsx — see
  // either one's own comment on this line).
  const { getHeaderAction } = useOutboundAddButton({ ...outboundConfig, onStartCall: handleStartCall });

  /* Shared app panel show/hide — same visibility state machine the AI +
     Notifications panels used before they were consolidated into this one
     shared panel (see `PanelState` above). */
  useEffect(() => {
    clearTimeout(panelAnimTimer.current);
    if (panelOpen) {
      if (containerRef.current && panelFloatLeft.current === null) {
        // Store absolute viewport x so the panel doesn't shift when the left nav opens/closes
        const r = containerRef.current.getBoundingClientRect();
        panelFloatLeft.current = r.left + containerRef.current.offsetWidth - panelWidth - 16;
      }
      setPanelHeight(computePanelHeight());
      setPanelMounted(true);
      setPanelState("open");   // data-state="open" → enter animation triggers
    } else {
      setPanelState("closing"); // data-state="closed" → exit animation plays
      panelAnimTimer.current = setTimeout(() => {
        setPanelState("closed");
      }, 150);
    }
    return () => clearTimeout(panelAnimTimer.current);
  }, [panelOpen]);

  /* Shrink panel height with viewport when open */
  useEffect(() => {
    if (!panelOpen) return;
    const onResize = () => setPanelHeight(computePanelHeight());
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [panelOpen]);

  const handlePanelVariantChange = (v: DraggableVariant) => {
    // When docking: read from the Draggable root element (not the fixed wrapper) so that
    // getBoundingClientRect() includes the CSS transform drag offset — the true visual position.
    // No cross-panel single-dock rule needed anymore — every app shares this
    // ONE panel, so there's never a second docked panel to displace.
    if (v === "docked" && panelRef.current) {
      const r = panelRef.current.getBoundingClientRect();
      panelFloatLeft.current = r.left;
      panelFloatTop.current  = r.top;
    }
    setPanelVariant(v);
  };

  /* Float position — stored and returned as absolute viewport x-coordinate
     so it doesn't shift when the left nav opens/closes (which changes
     rect.left but not the panel's intended position). zIndex 9999 — the §4
     "floating Draggable panels" base tier; with a single shared panel
     there's no front-most/`topPanel` split to track anymore, and the
     app-header menus (the "View All Apps" kebab, the app-switcher popover,
     both z-[9999] and portaled to document.body LATER in the DOM) still
     paint above it on the equal-z tie. */
  const getPanelFloatStyle = (): React.CSSProperties => {
    const rect = containerRef.current?.getBoundingClientRect();
    const left = panelFloatLeft.current !== null
      ? panelFloatLeft.current
      : containerRef.current
        ? (rect?.left ?? 0) + containerRef.current.offsetWidth - panelWidth - 16
        : 0;
    const top = panelFloatTop.current !== null
      ? panelFloatTop.current
      : (rect?.top ?? 0);
    return {
      position: "fixed",
      top,
      left,
      zIndex: 9999,
    };
  };

  /* ── Content for each app button ──
     All hooks called unconditionally every render (Rules of Hooks)
     regardless of which app's content the shared panel currently shows.
     Notifications is the REAL panel content the template rendered before —
     the same `useAgentNotificationsContent` hook `AgentNotifications`
     itself composes internally — with the exact same handlers, not a
     reimplementation. */
  const notifContent = useAgentNotificationsContent({
    notifications,
    onMarkAllRead: () => setNotifications((prev) => prev.map((n) => ({ ...n, read: true }))),
    onClearAll: () => setNotifications([]),
    onDismiss: (id) => setNotifications((prev) => prev.filter((n) => n.id !== id)),
    onNotificationClick: (n) => setNotifications((prev) => prev.map((i) => i.id === n.id ? { ...i, read: true } : i)),
  });
  const searchContent = useAgentSearchContent({
    query: globalSearchQuery,
    onQueryChange: setGlobalSearchQuery,
  });
  const screenPopContent = useScreenPopContent({
    app: screenPopApp,
    onAppChange: setScreenPopApp,
  });
  // Schedule keeps its view/anchorDate internal (uncontrolled) — nothing
  // else in this template needs to read them, matching the reference.
  const scheduleContent = useScheduleContent();
  const contentByPanelKey: Record<PanelKey, EmbeddablePanelContent> = {
    search: searchContent,
    // WEM has no real content yet — v2's shared blank placeholder.
    wem: {
      title: "WEM",
      body: (
        <div className="overflow-y-auto flex-1 flex items-center justify-center p-4">
          <p className="lyra-body-md text-lyra-fg-disabled text-center">Nothing here yet.</p>
        </div>
      ),
    },
    screenpop: screenPopContent,
    conversations: { title: "Agent Chat", body: <AgentChat /> },
    schedule: scheduleContent,
    notif: notifContent,
  };
  const activePanelContent = activePanelKey ? contentByPanelKey[activePanelKey] : null;
  const unreadCount = notifications.filter((n) => !n.read).length;

  /* Clicking an app button: re-clicking the CURRENTLY showing one closes
     the shared panel outright. Otherwise, if it's closed, open it docked;
     if it's already open showing a DIFFERENT key, only `activePanelKey`
     changes — the container itself never resizes, repositions, or
     re-animates open+close, only its title/body content does. Same
     contract as v2's `handlePanelButtonClick`. */
  const handlePanelButtonClick = (key: PanelKey) => {
    if (panelOpen && activePanelKey === key) {
      setPanelOpen(false);
      return;
    }
    if (!panelOpen) {
      setPanelVariant("docked");
      setPanelOpen(true);
    }
    setActivePanelKey(key);
  };

  /* "View All Apps" menu rows — every app (pinned or not) with its icon,
     the same click handler its header icon uses, and a trailing
     `PanelPinButton` controlling `pinnedKeys`. `KebabMenuButton` (not bare
     `Menu`) because its rows render as Radix `<div role="menuitem">`s
     rather than `<button>`s — required since each row nests a real
     `<button>` (`PanelPinButton`) in `rightElement`, which would be
     invalid HTML nested inside another button. `closeOnSelect: false` so a
     caller can pin/unpin or jump between several apps in one pass; the pin
     button's own click is wrapped in a `stopPropagation` span so it
     doesn't also fire the row's `onClick`. */
  const appsMenuItems: MenuEntry[] = PANEL_KEY_ORDER.map((key) => {
    const { label, icon: KeyIcon } = PANEL_KEY_METADATA[key];
    return {
      id: key,
      label,
      icon: <KeyIcon className="h-4 w-4" strokeWidth={1.5} />,
      // Mirrors the header icons' own `PANEL_BUTTON_SELECTED_CLASS`
      // condition — whichever app owns the shared panel reads active here too.
      active: panelOpen && activePanelKey === key,
      onClick: () => handlePanelButtonClick(key),
      closeOnSelect: false,
      rightElement: (
        <span className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
          {/* Same unread count `NotificationsBell`'s own header icon shows —
              reused, not recomputed with different criteria. `Badge`'s
              circle/critical/sm is the exact styling `Button`'s built-in
              `badge` prop uses for this count elsewhere (button.tsx) —
              reused directly since a menu row's `rightElement` isn't an
              icon-shaped `Button` itself. */}
          {key === "notif" && unreadCount > 0 && (
            <Badge shape="circle" variant="critical" size="sm" count={unreadCount} />
          )}
          <PanelPinButton
            pinned={pinnedKeys[key]}
            onToggle={() => setPinnedKeys((prev) => ({ ...prev, [key]: !prev[key] }))}
            pinnedLabel={`Unpin ${label}`}
            unpinnedLabel={`Pin ${label}`}
            /* Only override the icon/className when PINNED — unpinned rows
               pass neither prop, falling through to `PanelPinButton`'s own
               default rendering (plain gray outline Pin). Pinned rows get a
               solid blue pin (`fill-lyra-fg-active-strong` + matching
               `text-*`, the same "filled + colored icon" idiom
               `FavoriteButton`'s star uses) instead of the default's plain
               45°-rotated outline. Passing a custom `icon` also opts into
               `PanelPinButton`'s "selected button background" treatment —
               not wanted here, just the icon should read as filled/blue —
               so `className` overrides that back to transparent (twMerge
               drops the conflicting `bg-*`), also only when pinned. */
            icon={
              pinnedKeys[key] ? (
                <Pin className="h-4 w-4 rotate-45 fill-lyra-fg-active-strong text-lyra-fg-active-strong" strokeWidth={1.5} />
              ) : undefined
            }
            className={pinnedKeys[key] ? "bg-transparent hover:bg-lyra-state-hover" : undefined}
          />
        </span>
      ),
    };
  });

  /* How much room the DOCKED shared panel can claim without pushing
     `containerRef`'s own `min-w-[374px]` floor (and so the whole row) past
     the viewport — ported from v2 (see `INTERACTION_MAIN_CONTENT_MIN_WIDTH`'s
     doc comment). Feeds both `Draggable`'s `maxWidth` (so a live drag stops
     at the wall) and `dockedPanelRenderWidth`'s clamp in the docked render
     block. One adaptation vs. v2's `isNavNarrow ? 0 : ...`: this template's
     `LeftNav` keeps a 60px rail footprint even in overlay mode (left-nav.tsx),
     so narrow mode reserves 60, not 0. */
  const leftNavRenderWidth = !isNavNarrow && navOpen ? 256 : 60;
  const maxDockedWidthForMainFloor = Math.max(
    0,
    bodyContainerWidth - leftNavRenderWidth - INTERACTION_MAIN_CONTENT_MIN_WIDTH - 12
  );

  /* The one shared Draggable — its header (title/badge/actions) and body
     swap to whichever app's content is active; the container itself
     (variant/width/position) never does. Header shape ported from v2's
     `sharedPanel` (ContainerHeader + grip-in-float + dock/close actions),
     minus the per-app fullscreen action (out of scope). */
  const sharedPanel = panelMounted && activePanelContent ? (
    <Draggable
      ref={panelRef}
      variant={panelVariant}
      defaultWidth={panelWidth}
      defaultHeight={panelHeight}
      // Same real on-screen minimum as the main content column's floor —
      // v2's `SHARED_CONTENT_MIN_VISUAL_WIDTH`, not the old 280 (see the
      // constant's own doc comment for the padding asymmetry).
      minWidth={SHARED_CONTENT_MIN_VISUAL_WIDTH}
      minHeight={200}
      // This instance computes its own precise ceiling from real sibling
      // layout (`maxDockedWidthForMainFloor`) — opt out of `Draggable`'s
      // generic "below 1440px viewport, tighten to 800px" heuristic so the
      // floor-aware ceiling is the only cap, matching v2.
      disableResponsiveMaxWidth
      maxWidth={panelVariant === "docked" ? Math.min(SHARED_PANEL_MAX_WIDTH, maxDockedWidthForMainFloor) : SHARED_PANEL_MAX_WIDTH}
      onVariantChange={handlePanelVariantChange}
      onWidthChange={setPanelWidth}
      onResizeStateChange={setPanelIsResizing}
      className={cn(
        "rounded-lyra-lg border border-lyra-border-subtle",
        // Floating (undocked/dragged) gets an 80%-opacity background +
        // slight backdrop blur, matching v2 — plain `bg-lyra-bg-surface-
        // base/80` can't work here since Tailwind can't generate opacity-
        // modified utilities for our `var(--lyra-color-*)` tokens, so
        // `color-mix()` against the same variable is used instead. Docked
        // keeps the normal fully-opaque background.
        panelVariant === "float"
          ? "shadow-lg backdrop-blur-sm bg-[color-mix(in_srgb,var(--lyra-color-bg-surface-base)_80%,transparent)]"
          : "h-full bg-lyra-bg-surface-base"
      )}
      renderHeaderControls={({ gripProps, dockButtonProps, dockIcon, variant: dVariant }) => (
        <>
          <ContainerHeader
            title={activePanelContent.title}
            titleBadge={activePanelContent.titleBadge}
            titleClassName={activePanelContent.titleClassName}
            icon={
              dVariant === "float"
                ? <div {...gripProps}><GripVertical className="h-4 w-4" strokeWidth={1.5} /></div>
                : activePanelContent.dockedIcon
            }
            bordered={!activePanelContent.headerContent}
            actions={
              <>
                {activePanelContent.headerActions}
                <Tooltip content={dockButtonProps["aria-label"]} placement="bottom" asLabel>
                  <ActionIconButton
                    {...dockButtonProps}
                    size="sm"
                    className="text-lyra-fg-secondary hover:text-lyra-fg-secondary"
                  >
                    {dockIcon}
                  </ActionIconButton>
                </Tooltip>
              </>
            }
            onClose={() => setPanelOpen(false)}
          />
          {activePanelContent.headerContent && (
            // Fixed between the title row and the scrollable body — same
            // wrapper `DraggablePanel` gives its own `headerContent`.
            <div className="shrink-0 px-4 pb-3 border-b border-lyra-border-subtle">
              {activePanelContent.headerContent}
            </div>
          )}
        </>
      )}
    >
      {activePanelContent.body}
    </Draggable>
  ) : null;

  return (
    <div className="flex flex-col h-screen bg-lyra-bg-surface-shell overflow-hidden">

      {/* ── App Header ── */}
      <AppHeader
        appName={
          <PopoverPrimitive.Root open={appMenuOpen} onOpenChange={setAppMenuOpen}>
            <PopoverPrimitive.Trigger asChild>
              <AppName
                icon={<img src={appIcon} alt="Agent Next Gen" className="h-6 w-6" />}
                name="Agent Next Gen"
                compact={isCompactHeader}
                aria-expanded={appMenuOpen}
              />
            </PopoverPrimitive.Trigger>
            <PopoverPrimitive.Portal>
              <PopoverPrimitive.Content
                side="bottom"
                align="start"
                sideOffset={6}
                onOpenAutoFocus={(e: Event) => e.preventDefault()}
                className="z-[9999] animate-in fade-in-0 slide-in-from-top-2 duration-150 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:slide-out-to-top-1 data-[state=closed]:duration-100"
              >
                <AppMenu
                  groups={APP_MENU_GROUPS}
                  footer={<CXoneLogo />}
                  header={isCompactHeader ? "Agent Next Gen" : undefined}
                />
              </PopoverPrimitive.Content>
            </PopoverPrimitive.Portal>
          </PopoverPrimitive.Root>
        }
        actions={
          <>
            {/* Pinned app icon row — one `ActionIconButton size="xl"` (44px,
                the AppHeader standard) per pinned key, in `PANEL_KEY_ORDER`,
                each toggling the shared app panel to its own content.
                "notif" renders the specialized `NotificationsBell` (unread
                badge) instead of a generic icon button; unpinned keys stay
                reachable from the "View All Apps" kebab after the row.
                The standalone Ask AI button that used to sit here (with its
                own separate AiPanel) is gone — v2's Desk header has no AI
                button; see the "Top-right app panels" comment above the
                component. */}
            <div className="flex items-center gap-0">
              {PANEL_KEY_ORDER.filter((key) => pinnedKeys[key]).map((key) => {
                const { label, icon: KeyIcon } = PANEL_KEY_METADATA[key];
                const isActive = panelOpen && activePanelKey === key;
                return key === "notif" ? (
                  <NotificationsBell
                    key={key}
                    notifications={notifications}
                    open={isActive}
                    onOpenChange={() => handlePanelButtonClick("notif")}
                    renderPanel={false}
                  />
                ) : (
                  <ActionIconButton
                    key={key}
                    size="xl"
                    title={label}
                    aria-expanded={isActive}
                    onClick={() => handlePanelButtonClick(key)}
                    className={isActive ? PANEL_BUTTON_SELECTED_CLASS : undefined}
                  >
                    <KeyIcon className="h-5 w-5" strokeWidth={1.5} />
                  </ActionIconButton>
                );
              })}
            </div>
            {/* Separator between the icon row and the "View All Apps" kebab
                — same `h-auto self-stretch` sizing lyra-ui's other vertical
                Separator usages (dashboard-card.tsx's metric-row divider)
                use, so it stretches to the row's height inside AppHeader's
                `flex items-center` actions container. */}
            <Separator orientation="vertical" className="h-auto self-stretch pl-lyra-1 pr-lyra-1" />
            {/* Trailing "View All Apps" kebab — lists every app (pinned or
                not) with a pin toggle per row; see `appsMenuItems` above.
                Wrapped in `Tooltip`+`span` because `KebabMenuButton`'s
                trigger needs the intermediate span for Tooltip's `asChild`
                cloning (same fix as agent-notifications.tsx's overflow
                menu). Sized up from its 24px default to the 44px
                `ActionIconButton` standard via `className` (twMerge dedupes
                the conflicting h-6/w-6); "outline" treatment (border +
                `bg-lyra-bg-control`, same tokens as `Button`'s own outline
                variant) so it reads as a distinct "more" control rather
                than another app shortcut — reproduced directly since
                `KebabMenuButton` isn't built on `Button`. */}
            <Tooltip content="View All Apps" placement="bottom" disabled={appsMenuOpen}>
              <span className="inline-flex">
                <KebabMenuButton
                  items={appsMenuItems}
                  ariaLabel="View All Apps"
                  icon={<LayoutGrid className="h-5 w-5" strokeWidth={1.5} />}
                  className="h-11 w-11 rounded-lyra-sm border border-lyra-border-soft bg-lyra-bg-control text-lyra-fg-action hover:bg-lyra-state-hover active:bg-lyra-state-pressed data-[state=open]:bg-lyra-state-hover"
                  onOpenChange={setAppsMenuOpen}
                  // Once Notifications' own header icon is unpinned (its
                  // NotificationsBell badge gone with it), surface the same
                  // unread count here instead, so an unread notification is
                  // never silently invisible — only while the header ISN'T
                  // already showing that count itself, to avoid the same
                  // number appearing on two icons at once.
                  badge={!pinnedKeys.notif ? unreadCount : undefined}
                />
              </span>
            </Tooltip>
            <AgentProfile
              name="John Smith"
              initials="JS"
              status={agentStatus}
              onStatusChange={handleStatusChange}
              timer={formattedTimer}
              className="ml-1"
            />
          </>
        }
      />

      {/* ── Body: LeftNav + Content ── */}
      {/* overflow-hidden ensures docked panels never push layout past the viewport.
          ref measured by `bodyContainerRef` — feeds `maxDockedWidthForMainFloor`. */}
      <div ref={bodyContainerRef} className="flex flex-1 min-h-0 overflow-hidden">

        <LeftNav
          items={NAV_ITEMS}
          open={navOpen}
          onToggle={() => setNavOpen((v) => !v)}
          overlay={isNavNarrow}
          pinnedHeader={
            <CreateNew
              title="New Outbound"
              outbound={{
                ...outboundConfig,
                onStartCall: handleStartCall,
                onQuickDial: handleQuickDial,
              }}
              expanded={navOpen}
            />
          }
          header={
            <>
              {/* No cards until the agent actually starts one above — each
                  card is one contact (or quick-dialed number), with every
                  channel they're being reached on folded into that same
                  card unless it's a different address on an already-open
                  type, which opens as its own row instead (see
                  handleStartCall's merge-by-type+address logic). */}
              {interactions.map((interaction) => {
                const mostRecentId = interaction.channels[interaction.channels.length - 1]?.id;
                const currentId = interaction.currentChannelId ?? mostRecentId;
                const channels: InteractionChannel[] = interaction.channels.map((c) => ({
                  id: c.id,
                  type: c.type,
                  elapsed: formatElapsedTime(clockTick - c.startTick),
                  preview: c.preview,
                  current: c.id === currentId,
                  // Read straight off the tracked channel (see
                  // TrackedChannel.awaitingResponse's own doc comment) —
                  // not derived from `type` — so a freshly-started outbound
                  // channel never renders red just for being SMS/chat/
                  // email/WhatsApp instead of voice.
                  awaitingResponse: c.awaitingResponse ?? false,
                }));
                const earliestStart = Math.min(...interaction.channels.map((c) => c.startTick));
                return (
                  <InteractionNavItem
                    key={interaction.id}
                    customerName={interaction.customerName}
                    active={activeInteractionId === interaction.id}
                    onClick={() => setActiveInteractionId(interaction.id)}
                    awaitingResponse={channels.some((c) => c.awaitingResponse)}
                    elapsed={formatElapsedTime(clockTick - earliestStart)}
                    expanded={navOpen}
                    channels={channels}
                    onDismiss={() => handleDismissInteraction(interaction.id)}
                    onDismissChannel={(channel) => handleDismissChannel(interaction.id, channel)}
                    headerAction={getHeaderAction(interaction.id)}
                    currentChannelKey={currentId}
                    onCurrentChannelChange={(key) => handleChannelSelect(interaction.id, key)}
                  />
                );
              })}
            </>
          }
        />

        {/* Content area — flex-1 shrinks to give space to docked panels, but
            never below `INTERACTION_MAIN_CONTENT_MIN_WIDTH` (374 = 362 visual
            + 12 `pr-3`; keep the literal in sync with the constant by hand) —
            below that, the docked panel's own render width clamps down instead
            (`dockedPanelRenderWidth`) so this floor never pushes the row past
            the viewport. Matches v2. ref used to position float panels. */}
        <div ref={containerRef} className="relative flex flex-1 min-w-[374px] overflow-hidden pr-3 pb-3">

          {/* Main Container — flex row so pinned Panel sits left of PageHeader + content.
              relative so unpinned Panel can overlay the full surface. */}
          <Container className="flex flex-1 overflow-hidden relative">

            {/* Customer Information Panel — one instance whose `pinned` prop
                just flips SidePanel's own internal inline-vs-overlay branch,
                matching the "Side Panel" story (a single element, props
                toggle) so the width transition animates correctly. Gated on
                `activeInteraction`, not just `showPanelToggle` — its only
                trigger is the record icon on the interaction `PageHeader`
                below, which doesn't exist on the "Home" page.
                Was a bare `<SidePanel headerTitle="Designer" .../>` with no
                body content — swapped for `CustomerInformationPanel`, which
                fixes the header to "Customer Information" and adds a
                "{name} · {id}" subhead for whoever this interaction is
                with. See agent-next-gen-v1's copy of this block for the
                full rationale. */}
            {showPanelToggle && activeInteraction && (
              <CustomerInformationPanel
                side="left"
                open={sidePanelOpen}
                pinned={effectivePinned}
                person={{ name: activeInteraction.customerName ?? "Customer", id: activeInteraction.recordId }}
                onPinToggle={isNarrowContainer ? undefined : handleSidePanelPinToggle}
                width={sidePanelWidth}
                onWidthChange={setSidePanelWidth}
                onResizeStateChange={setSidePanelResizing}
                onMouseEnter={onSidePanelHoverStart}
                onMouseLeave={sidePanelResizing ? undefined : onSidePanelHoverEnd}
              />
            )}

            {/* Content column: PageHeader + page body */}
            <div className="flex flex-1 flex-col min-w-0 overflow-hidden">
              {activeInteraction ? (
                // ── Active interaction's detail page — replaces the "Home"
                // page the moment a new assignment is started/quick-dialed
                // (see `activeInteraction` above). Just the record header for
                // now; the blank body below is where a real case/contact
                // detail view will go. Reverts back automatically once the
                // interaction is dismissed (`activeInteractionId` clears).
                <>
                  {showPageHeader && (
                    <PageHeader
                      // Hovering this record icon reveals the Designer side
                      // panel; clicking it is a real on/off toggle via the
                      // shared `PanelPinButton` atom — the same trigger
                      // `Panel`'s own internal pin button uses, just with its
                      // icon swapped to `User`. See agent-next-gen-v1's copy
                      // of this block for the full rationale.
                      icon={
                        <span
                          onMouseEnter={onSidePanelHoverStart}
                          onMouseLeave={sidePanelResizing ? undefined : onSidePanelHoverEnd}
                        >
                          <PanelPinButton
                            pinned={sidePanelPinned}
                            onToggle={handleSidePanelIconToggle}
                            icon={<User className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />}
                            pinnedLabel={sidePanelToggleLabel ?? "Unpin Designer panel"}
                            unpinnedLabel={sidePanelToggleLabel ?? "Pin Designer panel"}
                          />
                        </span>
                      }
                      iconAriaHidden={false}
                      title={activeInteraction.customerName ?? "Customer"}
                      subtitle={activeInteraction.recordId}
                    />
                  )}
                  {/* One tab per open channel — kept in sync with the same
                      interaction's InteractionNavItem card via
                      currentChannelId/handleChannelSelect. Shown even with
                      just one channel open. See agent-next-gen-v1's own
                      copy of this block. */}
                  {showPageHeader && activeInteraction.channels.length > 0 && (
                    <TabList className="px-6 bg-lyra-bg-surface-base shrink-0" overflowMenu>
                      {activeInteraction.channels.map((c) => {
                        const key = c.id ?? c.type;
                        return (
                          <ChannelTab
                            key={key}
                            type={c.type}
                            address={c.addressLabel}
                            messageCount={c.messageCount}
                            interactionId={c.interactionId}
                            active={(activeInteraction.currentChannelId ?? activeInteraction.channels[activeInteraction.channels.length - 1]?.id) === key}
                            onClick={() => handleChannelSelect(activeInteraction.id, key)}
                            onDismiss={() => {
                              if (activeInteraction.channels.length > 1) handleDismissChannel(activeInteraction.id, c);
                              else handleDismissInteraction(activeInteraction.id);
                            }}
                          />
                        );
                      })}
                    </TabList>
                  )}
                  <div className="flex-1 overflow-y-auto" />
                </>
              ) : (
                <>
                  {showPageHeader && (
                    <PageHeader
                      title="Home"
                      panelToggle={
                        showPanelToggle && showInteriorPanel ? "both"
                        : showPanelToggle ? "left"
                        : showInteriorPanel ? "right"
                        : undefined
                      }
                      panelPinned={effectivePinned}
                      onPanelToggle={effectivePinned ? () => setSidePanelOpen((v) => !v) : undefined}
                      onPanelHoverStart={!effectivePinned ? onSidePanelHoverStart : undefined}
                      onPanelHoverEnd={!effectivePinned ? onSidePanelHoverEnd : undefined}
                      onInnerPanelToggle={showInteriorPanel ? () => setInteriorPanelOpen((v) => !v) : undefined}
                      actions={
                        <>
                          <Button variant="outline">Export</Button>
                          <Button>
                            <Plus className="h-4 w-4" strokeWidth={1.5} />
                            New Case
                          </Button>
                        </>
                      }
                    />
                  )}
                  {/* Body row: main content + interior panel */}
                  <div className="relative flex flex-1 overflow-hidden">
                    <div className="flex-1" />
                    {showInteriorPanel && (
                      <InteriorPanel
                        side="right"
                        open={interiorPanelOpen}
                        headerTitle="Case Details"
                        onClose={() => setInteriorPanelOpen(false)}
                      >
                        <div className="flex flex-col gap-4 px-4 py-4">
                          <Input label="Subject" placeholder="Enter subject" />
                          <Input label="Priority" placeholder="Select priority" />
                          <Input label="Assignee" placeholder="Search agents" />
                          <Input label="Tags" placeholder="Add tags" />
                        </div>
                      </InteriorPanel>
                    )}
                  </div>
                </>
              )}
            </div>

          </Container>

          {/* Shared app panel — float
            * Uses CSS transitions (not keyframe animations) to avoid the GPU compositor
            * fill-mode flash. Transitions interpolate between explicit values with no
            * animation lifecycle; visibility:hidden keeps the element in the render tree
            * so the close transition always completes before the element is hidden.
            * pointerEvents:"none" on this positioning wrapper is load-bearing (the
            * documented Draggable ghost-hit-area rule): the panel itself moves via CSS
            * transform, this wrapper's layout box does NOT — Draggable's own root
            * already sets pointer-events:auto on itself, so no inner "auto" div either. */}
          {panelVariant === "float" && panelMounted && (
            <div
              style={{
                ...getPanelFloatStyle(),
                pointerEvents: "none",
                visibility: panelState === "closed" ? "hidden" : "visible",
                opacity: panelState === "open" ? 1 : 0,
                transform: panelState === "open" ? "translateY(0)" : "translateY(-8px)",
                transition: panelState === "open"
                  ? "opacity 150ms ease, transform 150ms ease"
                  : "opacity 100ms ease, transform 100ms ease",
              }}
            >
              {sharedPanel}
            </div>
          )}

        </div>

        {/* Shared app panel — docked (sibling of containerRef so flex layout
            keeps it in-bounds). This is the template's single dock slot —
            every app's content shares it via `activePanelKey`. */}
        {panelVariant === "docked" && (() => {
          /* Clamp the rendered width to the floor-aware ceiling (not just the
             drag ceiling on `Draggable`'s `maxWidth`) so a panel widened on a
             large window can't push `containerRef` under its `min-w-[374px]`
             floor after the window shrinks — the panel is the sibling that
             gives up space. Matches v2's `dockedPanelRenderWidth`. */
          const dockedPanelRenderWidth = Math.min(panelWidth, maxDockedWidthForMainFloor);
          return (
          <div className="pb-3" style={{
            width: panelState === "open" ? dockedPanelRenderWidth : 0,
            marginRight: panelState === "open" ? 12 : 0,
            overflow: "hidden",
            flexShrink: 0,
            transition: panelIsResizing ? "none" : "width 250ms cubic-bezier(0.4, 0, 0.2, 1)",
          }}>
            <div
              className="h-full animate-in fade-in-0 duration-150"
              style={{
                width: dockedPanelRenderWidth,
                display: panelState === "open" ? "block" : "none",
              }}
            >
              {sharedPanel}
            </div>
          </div>
          );
        })()}

      </div>
    </div>
  );
}

/* ── Story ── */

const meta: Meta<typeof AgentNextGenTemplate> = {
  title: "Templates/Agent Next Gen",
  component: AgentNextGenTemplate,
  parameters: {
    layout: "fullscreen",
    backgrounds: { default: "lyra-shell" },
  },
};

export default meta;
type Story = StoryObj<typeof AgentNextGenTemplate>;

export const Default: Story = {
  name: "Agent Next Gen – Shell",
  render: () => <AgentNextGenTemplate />,
};

export const WithPageHeader: Story = {
  name: "Agent Next Gen – With Page Header",
  args: {
    showPanelToggle: true,
    showInteriorPanel: true,
  },
  argTypes: {
    showPanelToggle: {
      control: "boolean",
      description: "Show the left panel toggle button in the page header",
    },
    showInteriorPanel: {
      control: "boolean",
      description: "Show the right interior (Case Details) panel",
    },
  },
  render: (args) => (
    <AgentNextGenTemplate
      showPageHeader
      showPanelToggle={args.showPanelToggle}
      showInteriorPanel={args.showInteriorPanel}
    />
  ),
};

/* ── Active Interaction ──
   Same template, but seeded via `initialInteraction` (see
   `ACTIVE_INTERACTION_DEMO` above) so it renders straight into the
   interaction detail view — record header, single Voice `ChannelTab`, and
   the matching `InteractionNavItem` card already expanded in the left nav
   — instead of requiring a manual New Outbound click first. Useful as a
   stable reference for what an in-progress call actually looks like. */
export const ActiveInteractionStory: Story = {
  name: "Agent Next Gen – Active Interaction",
  args: {
    showPanelToggle: true,
    showInteriorPanel: false,
  },
  argTypes: {
    showPanelToggle: {
      control: "boolean",
      description: "Show the left panel toggle button in the page header",
    },
    showInteriorPanel: {
      control: "boolean",
      description: "Show the right interior (Case Details) panel",
    },
  },
  render: (args) => (
    <AgentNextGenTemplate
      showPageHeader
      showPanelToggle={args.showPanelToggle}
      showInteriorPanel={args.showInteriorPanel}
      initialInteraction={ACTIVE_INTERACTION_DEMO}
      sidePanelToggleLabel="Toggle Overview"
    />
  ),
};
